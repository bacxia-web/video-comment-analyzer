# 隐私说明

Video & Comment Analyzer 是用户自行配置服务 Key 的 Chrome 扩展，没有开发者运营的数据服务器。

## 本地保存

DeepSeek、YouTube Data API、Supadata Key 保存于本机扩展的 `chrome.storage.local`，不使用 Chrome 同步存储。后台将此存储限制为 `TRUSTED_CONTEXTS`，普通网页和内容脚本无法读取。

Key 不会写入源码、导出内容或 GitHub。它们不是经过独立密码加密的保险库数据；有权访问本机浏览器资料的人可能读取本地存储。

统一面板的字幕、评论和分析结果保留在内存中，关闭面板后不保留。用户主动导出的 Markdown / JSON 文件可能包含公开评论者昵称和评论原文。保留的旧版 YouTube 学习工具会在扩展本地存储保存笔记、摘要和翻译缓存。

## 向外部服务发送什么

- **DeepSeek**：仅在用户点击分析时发送当前采集的字幕或评论样本、内容标题和创作者信息，以及用户输入的 DeepSeek Key 用于鉴权。旧版学习工具中的翻译、解释、笔记整理也会调用 DeepSeek。
- **Google YouTube Data API**：采集 YouTube 评论时发送视频 ID、分页参数和用户配置的 Google Key。
- **Supadata**：只有配置了该可选服务，并且原生 YouTube 字幕不可用时，统一面板才发送不含追踪参数的标准视频 URL 和 Supadata Key。旧版学习工具直接使用 Supadata 获取字幕。字幕请求使用 `mode=native`。
- **YouTube / 哔哩哔哩**：读取网站原生字幕。B 站请求当前视频信息、当前分 P 的字幕列表及字幕内容，沿用用户在网站的登录状态，不提取或导出 Cookie。
- **小红书**：在当前笔记页面自动滚动、展开回复并读取可见评论，正常页面加载可能触发网站自己的请求。
- **雪球**：使用当前网站登录会话请求当前帖子的评论接口。

不向 DeepSeek、Google 或 Supadata 发送用户的网站 Cookie。API Key 不会传入执行于网页中的采集函数。没有遥测、广告追踪或后台自动分析。

## 控制与删除

设置页面可修改或清除 API Key；卸载插件可以清除该扩展的本地存储。下载的导出文件需要用户自行删除。网站登录由各网站管理，不受清除插件 Key 操作影响。

第三方 API 的数据保留与收费政策以服务商的说明为准。仅采集按钮不会发送内容给 DeepSeek，但 YouTube 评论 API 或配置过的备用字幕服务仍可能消耗相应服务额度。
